﻿using System;
using System.Diagnostics;
using System.Data;

namespace POC_DiposeObject
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "Server=10.10.2.77;Database=vikor_demo;User Id=sa;Password=bD!0YP4A0D1@;MultipleActiveResultSets=True;Connect Timeout=10000;Integrated Security=False;TrustServerCertificate=True";


            Console.WriteLine("======== 🧪 OBJECT DISPOSAL TEST POC ========\n");

            TestWithDispose(connectionString);
            Console.WriteLine("\n------------------------------------------\n");
            TestWithoutDispose(connectionString);

            Console.WriteLine("\n======== ✅ TEST COMPLETE ========");
            Console.ReadLine();
        }

        static void TestWithDispose(string conn)
        {
            Console.WriteLine("🔵 Test 1: With Proper Dispose");

            DataSet ds = null;

            var stopwatch = Stopwatch.StartNew();
            LogGCStats("Before");

            using (var repo = new UserRepositoryWithDispose(conn))
            {
                using (ds = repo.GetUsersDataSet())
                {
                    Console.WriteLine($"✅ Rows fetched: {ds.Tables[0].Rows.Count}");

                    if (ds != null)
                        Console.WriteLine("🔍 DataSet object is currently alive inside using block.");
                }
                Console.WriteLine("ℹ️ DataSet disposed after using block.");
            }

            // Remove reference to allow GC
            ds = null;

            TriggerManualGC("TestWithDispose()");
            stopwatch.Stop();
            LogGCStats("After Dispose + GC");

            if (ds == null)
                Console.WriteLine("✅ DataSet object reference is null after Dispose and GC.");
            else
                Console.WriteLine("⚠️ DataSet object reference still alive after Dispose and GC.");

            Console.WriteLine($"⏱ Execution Time: {stopwatch.ElapsedMilliseconds} ms");
        }

        static void TestWithoutDispose(string conn)
        {
            Console.WriteLine("🔴 Test 2: Without Dispose");

            var stopwatch = Stopwatch.StartNew();
            LogGCStats("Before");

            var repo = new UserRepositoryWithoutDispose(conn);
            var ds = repo.GetUsersDataSet();

            Console.WriteLine($"✅ Rows fetched: {ds.Tables[0].Rows.Count}");

            if (ds != null)
                Console.WriteLine("⚠️ DataSet object NOT disposed and still alive after fetching.");

           // TriggerManualGC("TestWithoutDispose()");
            stopwatch.Stop();
            LogGCStats("After (no dispose, GC triggered)");

            if (ds != null)
                Console.WriteLine("⚠️ DataSet object still alive after manual GC because not disposed and reference held.");
            else
                Console.WriteLine("✅ DataSet object reference is null after manual GC.");

            Console.WriteLine($"⏱ Execution Time: {stopwatch.ElapsedMilliseconds} ms");
        }

        public static void TriggerManualGC(string source)
        {
            Console.WriteLine($"\n🔧 Manually triggering GC from: {source}");
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        public static void LogGCStats(string label)
        {
            long mem = GC.GetTotalMemory(false);
            long gen0 = GC.CollectionCount(0);
            long gen1 = GC.CollectionCount(1);
            long gen2 = GC.CollectionCount(2);

            Console.WriteLine($"\n🧠 [{label}]");
            Console.WriteLine($"📈 Memory Usage: {mem / 1024.0 / 1024.0:N2} MB");
            Console.WriteLine($"♻️ GC Count: Gen0 = {gen0}, Gen1 = {gen1}, Gen2 = {gen2}");
        }
    }

}

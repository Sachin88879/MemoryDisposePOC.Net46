﻿
    using System;
    using System.Data;
    using System.Data.SqlClient;

    namespace POC_DiposeObject
    {
        public class UserRepositoryWithDispose : IDisposable
        {
            private readonly string _connectionString;
            private bool _disposed = false;

            public UserRepositoryWithDispose(string connectionString)
            {
                _connectionString = connectionString;
            }

            public DataSet GetUsersDataSet()
            {
                var ds = new DataSet();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    string query = "SELECT  top 10000 * from common.encounters";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        con.Open();
                        adapter.Fill(ds);
                    }
                }
                return ds;
            }

            public void Dispose()
            {
                if (!_disposed)
                {
                    // No unmanaged resources, but simulate cleanup
                    Console.WriteLine("🧹 UserRepositoryWithDispose: Disposed");
                    _disposed = true;
                }
            }
        }
    }

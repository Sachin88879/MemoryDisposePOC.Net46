﻿
    using System.Data;
    using System.Data.SqlClient;

    namespace POC_DiposeObject
    {
        public class UserRepositoryWithoutDispose
        {
            private readonly string _connectionString;

            public UserRepositoryWithoutDispose(string connectionString)
            {
                _connectionString = connectionString;
            }

            public DataSet GetUsersDataSet()
            {
                var ds = new DataSet();

                SqlConnection con = new SqlConnection(_connectionString);
                SqlCommand cmd = new SqlCommand("SELECT top 10000 * from common.encounters", con);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                con.Open();
                adapter.Fill(ds);

                // ❌ No using, no Dispose - connection held in memory
                return ds;
            }
        }
    }



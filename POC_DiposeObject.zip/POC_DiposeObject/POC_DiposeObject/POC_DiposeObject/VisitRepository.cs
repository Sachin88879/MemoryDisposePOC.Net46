﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace POC_DiposeObject
{

        public class VisitRepository : IDisposable
        {
            private readonly string _connectionString;
            private bool _disposed = false;

            public VisitRepository(string connectionString)
            {
                _connectionString = connectionString;
                Console.WriteLine("🔄 VisitRepository initialized.");
            }

            public DataSet GetVisitDataSet(string encounterId)
            {
                var ds = new DataSet();
                Console.WriteLine("📦 [GetVisitDataSet] DataSet created.");

                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("GetVisitData", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@encounterid", encounterId);

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            adapter.Fill(ds);
                        }
                    }
                }

                return ds; // Will be disposed in calling method using `using`
            }

            public DataTable GetVisitDataTable(string encounterId)
            {
                using (var ds = GetVisitDataSet(encounterId))
                {
                    if (ds.Tables.Count > 0)
                    {
                        Console.WriteLine("📄 [GetVisitDataTable] DataTable copied and returned.");
                        return ds.Tables[0].Copy(); // Detached copy
                    }
                }

                return new DataTable();
            }

            public DataRow GetVisitDataRow(string encounterId)
            {
                using (var ds = GetVisitDataSet(encounterId))
                {
                    if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    {
                        Console.WriteLine("📌 [GetVisitDataRow] DataRow extracted.");
                        return ds.Tables[0].Rows[0];
                    }
                }

                return null;
            }

            public void Dispose()
            {
                if (!_disposed)
                {
                    Console.WriteLine("🗑️ VisitRepository disposed.");
                    _disposed = true;
                }
            }
        
        }

}
